
const Features = () => {
  const features = [
    {
      icon: '⚡',
      title: 'Instant Deposits',
      description: 'Lightning-fast crypto deposits with zero confirmations needed'
    },
    {
      icon: '🔒',
      title: 'Provably Fair',
      description: 'Every game result is cryptographically verifiable and transparent'
    },
    {
      icon: '🏆',
      title: 'VIP Rewards',
      description: 'Exclusive bonuses, cashback, and personal account managers'
    },
    {
      icon: '💬',
      title: '24/7 Support',
      description: 'Round-the-clock live chat support in multiple languages'
    },
    {
      icon: '📱',
      title: 'Mobile Optimized',
      description: 'Seamless gaming experience across all devices'
    },
    {
      icon: '🌍',
      title: 'Global Access',
      description: 'Available worldwide with multi-currency support'
    }
  ];

  return (
    <section className="py-20 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-4">
            Why Choose Us?
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            The most advanced crypto casino platform with cutting-edge features designed for the modern player
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="backdrop-blur-xl bg-gradient-to-br from-white/5 to-white/10 rounded-2xl border border-gray-600/30 p-8 text-center hover:border-cyan-400/50 transition-all duration-300 group"
            >
              <div className="text-6xl mb-6 group-hover:animate-bounce">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-white mb-4 group-hover:text-cyan-400 transition-colors">
                {feature.title}
              </h3>
              <p className="text-gray-300 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="backdrop-blur-xl bg-gradient-to-r from-cyan-500/10 to-purple-500/10 rounded-3xl border border-cyan-500/20 p-12 max-w-4xl mx-auto">
            <h3 className="text-3xl font-bold text-white mb-4">
              Ready to Start Winning?
            </h3>
            <p className="text-xl text-gray-300 mb-8">
              Join thousands of players and experience the future of online gaming
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white px-8 py-4 text-lg font-bold rounded-xl shadow-lg shadow-cyan-500/25 transform hover:scale-105 transition-all duration-300">
                🎮 Start Playing Now
              </button>
              <button className="border-2 border-purple-500 text-purple-400 hover:bg-purple-500/10 px-8 py-4 text-lg font-bold rounded-xl transition-all duration-300">
                📊 View Leaderboards
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
