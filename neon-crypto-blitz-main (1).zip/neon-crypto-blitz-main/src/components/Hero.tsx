
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';

const Hero = () => {
  const [currentGame, setCurrentGame] = useState(0);
  
  const featuredGames = [
    { name: 'Crash', emoji: '🚀', multiplier: '2.45x', status: 'Live' },
    { name: 'Mines', emoji: '💣', win: '+$1,250', status: 'Hot' },
    { name: 'Dice', emoji: '🎲', chance: '47.5%', status: 'Popular' },
    { name: 'Plinko', emoji: '🔴', drop: 'Active', status: 'Trending' }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentGame((prev) => (prev + 1) % featuredGames.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative py-20 px-4">
      <div className="container mx-auto text-center">
        {/* Main Hero Content */}
        <div className="mb-12">
          <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent animate-pulse">
            INSTANT WINS
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Experience the thrill of <span className="text-cyan-400 font-bold">provably fair</span> crypto gaming.
            Lightning-fast deposits, instant withdrawals, and games that never sleep.
          </p>
        </div>

        {/* Featured Game Carousel */}
        <div className="relative mb-12">
          <div className="backdrop-blur-xl bg-white/5 rounded-3xl border border-cyan-500/20 p-8 max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {featuredGames.map((game, index) => (
                <div
                  key={game.name}
                  className={`relative p-6 rounded-2xl transition-all duration-500 transform ${
                    index === currentGame
                      ? 'bg-gradient-to-br from-cyan-500/20 to-purple-600/20 scale-105 border-2 border-cyan-400'
                      : 'bg-white/5 hover:bg-white/10 border border-gray-600/30'
                  }`}
                >
                  <div className="text-4xl mb-3">{game.emoji}</div>
                  <h3 className="text-xl font-bold text-white mb-2">{game.name}</h3>
                  <div className="text-cyan-400 font-bold">
                    {game.multiplier || game.win || game.chance || game.drop}
                  </div>
                  <div className={`text-xs px-2 py-1 rounded-full mt-2 inline-block ${
                    game.status === 'Live' ? 'bg-red-500' :
                    game.status === 'Hot' ? 'bg-orange-500' :
                    game.status === 'Popular' ? 'bg-green-500' : 'bg-purple-500'
                  }`}>
                    {game.status}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white px-8 py-4 text-lg font-bold rounded-xl shadow-lg shadow-cyan-500/25 transform hover:scale-105 transition-all duration-300">
            🎮 Play Now
          </Button>
          <Button variant="outline" className="border-purple-500/50 text-purple-400 hover:bg-purple-500/10 px-8 py-4 text-lg rounded-xl">
            ✅ Provably Fair
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Hero;
