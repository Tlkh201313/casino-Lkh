
import { useState, useEffect } from 'react';

const LiveStats = () => {
  const [crashMultiplier, setCrashMultiplier] = useState(1.00);
  const [isActive, setIsActive] = useState(true);
  
  const recentWinners = [
    { player: 'CryptoKing', game: 'Crash', amount: '$2,450', multiplier: '3.25x' },
    { player: 'MoonShot', game: 'Mines', amount: '$1,890', mines: '5/24' },
    { player: 'DiamondHands', game: 'Dice', amount: '$987', roll: '87.3' },
    { player: 'RocketMaster', game: 'Crash', amount: '$3,200', multiplier: '4.12x' },
    { player: 'LuckyPlayer', game: 'Plinko', amount: '$1,200', balls: '100x' }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      if (isActive) {
        setCrashMultiplier(prev => {
          const newValue = prev + 0.01;
          if (newValue > 5.0 && Math.random() < 0.3) {
            setIsActive(false);
            setTimeout(() => {
              setCrashMultiplier(1.00);
              setIsActive(true);
            }, 3000);
            return prev;
          }
          return newValue;
        });
      }
    }, 100);

    return () => clearInterval(timer);
  }, [isActive]);

  return (
    <section className="py-12 px-4">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Live Crash Game */}
          <div className="backdrop-blur-xl bg-gradient-to-br from-red-500/10 to-orange-500/10 rounded-3xl border border-red-500/20 p-8">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-white mb-4">🚀 Live Crash Game</h3>
              <div className="relative">
                <div className={`text-8xl font-bold mb-4 transition-all duration-300 ${
                  isActive ? 'text-green-400 animate-pulse' : 'text-red-400'
                }`}>
                  {crashMultiplier.toFixed(2)}x
                </div>
                <div className={`text-lg font-medium ${
                  isActive ? 'text-green-400' : 'text-red-400'
                }`}>
                  {isActive ? '🟢 Flying High!' : '💥 Crashed!'}
                </div>
              </div>
              <div className="mt-6 flex justify-center space-x-4">
                <div className="bg-white/10 rounded-lg px-4 py-2">
                  <div className="text-sm text-gray-400">Players</div>
                  <div className="text-xl font-bold text-cyan-400">1,247</div>
                </div>
                <div className="bg-white/10 rounded-lg px-4 py-2">
                  <div className="text-sm text-gray-400">Total Bet</div>
                  <div className="text-xl font-bold text-green-400">$12,580</div>
                </div>
              </div>
            </div>
          </div>

          {/* Recent Winners */}
          <div className="backdrop-blur-xl bg-gradient-to-br from-green-500/10 to-cyan-500/10 rounded-3xl border border-green-500/20 p-8">
            <h3 className="text-2xl font-bold text-white mb-6 text-center">🏆 Recent Big Wins</h3>
            <div className="space-y-4 max-h-80 overflow-y-auto">
              {recentWinners.map((winner, index) => (
                <div key={index} className="flex items-center justify-between bg-white/5 rounded-lg p-4 hover:bg-white/10 transition-colors">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-sm font-bold">
                      {winner.player[0]}
                    </div>
                    <div>
                      <div className="font-medium text-white">{winner.player}</div>
                      <div className="text-sm text-gray-400">{winner.game}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-green-400">{winner.amount}</div>
                    <div className="text-sm text-cyan-400">
                      {winner.multiplier || winner.mines || winner.roll || winner.balls}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LiveStats;
