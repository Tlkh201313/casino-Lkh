
import { Button } from '@/components/ui/button';

const GameGrid = () => {
  const games = [
    { name: 'Crash', emoji: '🚀', players: '2.4k', rtp: '99%', volatility: 'High' },
    { name: 'Mines', emoji: '💣', players: '1.8k', rtp: '97%', volatility: 'Medium' },
    { name: 'x2 Double', emoji: '🎯', players: '3.1k', rtp: '98%', volatility: 'Low' },
    { name: 'Dice', emoji: '🎲', players: '1.2k', rtp: '99%', volatility: 'Medium' },
    { name: 'Tower', emoji: '🧱', players: '890', rtp: '97%', volatility: 'High' },
    { name: 'Plinko', emoji: '🔴', players: '1.5k', rtp: '98%', volatility: 'Medium' },
    { name: 'Lucky Wheel', emoji: '🎡', players: '2.1k', rtp: '96%', volatility: 'High' },
    { name: 'Limbo', emoji: '⚡', players: '967', rtp: '99%', volatility: 'High' }
  ];

  return (
    <section className="py-16 px-4" id="games">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-4">
            Instant Games
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Lightning-fast games with provably fair results. No downloads, no waiting.
          </p>
        </div>

        {/* Game Filters */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {['All Games', 'High Volatility', 'Medium Risk', 'Low Risk', 'Hot Games'].map((filter) => (
            <Button
              key={filter}
              variant="outline"
              className="border-purple-500/50 text-purple-400 hover:bg-purple-500/20 hover:border-purple-400"
            >
              {filter}
            </Button>
          ))}
        </div>

        {/* Games Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {games.map((game, index) => (
            <div
              key={game.name}
              className="group relative backdrop-blur-xl bg-gradient-to-br from-white/5 to-white/10 rounded-2xl border border-gray-600/30 p-6 hover:border-cyan-400/50 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/25"
            >
              {/* Game Icon */}
              <div className="text-center mb-4">
                <div className="text-6xl mb-3 group-hover:animate-bounce">
                  {game.emoji}
                </div>
                <h3 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors">
                  {game.name}
                </h3>
              </div>

              {/* Game Stats */}
              <div className="space-y-3 mb-6">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Players Online</span>
                  <span className="text-green-400 font-bold">{game.players}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">RTP</span>
                  <span className="text-cyan-400 font-bold">{game.rtp}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Volatility</span>
                  <span className={`font-bold ${
                    game.volatility === 'High' ? 'text-red-400' :
                    game.volatility === 'Medium' ? 'text-yellow-400' : 'text-green-400'
                  }`}>
                    {game.volatility}
                  </span>
                </div>
              </div>

              {/* Play Button */}
              <Button className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white font-bold py-3 rounded-xl transition-all duration-300 group-hover:shadow-lg group-hover:shadow-cyan-500/25">
                Play Now
              </Button>

              {/* Glow Effect */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-cyan-500/0 to-purple-500/0 group-hover:from-cyan-500/10 group-hover:to-purple-500/10 transition-all duration-300 pointer-events-none"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GameGrid;
