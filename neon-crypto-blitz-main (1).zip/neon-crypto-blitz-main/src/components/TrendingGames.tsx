
const TrendingGames = () => {
  const trendingGames = [
    { 
      name: 'Mega Crash', 
      emoji: '🚀', 
      trend: '+45%', 
      prize: '$50,000',
      description: 'Biggest multipliers this week!'
    },
    { 
      name: 'Diamond Mines', 
      emoji: '💎', 
      trend: '+32%', 
      prize: '$25,000',
      description: 'Find the diamonds, avoid the bombs'
    },
    { 
      name: 'Lightning Dice', 
      emoji: '⚡', 
      trend: '+28%', 
      prize: '$15,000',
      description: 'Electrifying wins await!'
    }
  ];

  return (
    <section className="py-16 px-4 bg-gradient-to-r from-purple-900/20 to-cyan-900/20">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent mb-4">
            🔥 Trending Now
          </h2>
          <p className="text-xl text-gray-300">
            The hottest games everyone's playing right now
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {trendingGames.map((game, index) => (
            <div
              key={game.name}
              className="relative backdrop-blur-xl bg-gradient-to-br from-orange-500/10 to-red-500/10 rounded-3xl border border-orange-500/30 p-8 group hover:border-orange-400 transition-all duration-300"
            >
              {/* Trending Badge */}
              <div className="absolute -top-3 -right-3 bg-gradient-to-r from-red-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm font-bold animate-pulse">
                🔥 {game.trend}
              </div>

              <div className="text-center">
                <div className="text-8xl mb-4 group-hover:animate-spin">
                  {game.emoji}
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">{game.name}</h3>
                <p className="text-gray-300 mb-4">{game.description}</p>
                
                <div className="bg-white/10 rounded-lg p-4 mb-6">
                  <div className="text-sm text-gray-400 mb-1">Max Prize Pool</div>
                  <div className="text-3xl font-bold text-yellow-400">{game.prize}</div>
                </div>

                <button className="w-full bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold py-4 rounded-xl transition-all duration-300 transform hover:scale-105">
                  Join the Trend
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrendingGames;
