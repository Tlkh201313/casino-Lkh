
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { LogOut, User, Coins } from 'lucide-react';

const Header = () => {
  const { user, profile, signOut, loading } = useAuth();
  const navigate = useNavigate();

  const handleAuthAction = () => {
    if (user) {
      signOut();
    } else {
      navigate('/auth');
    }
  };

  return (
    <header className="relative z-50 backdrop-blur-xl bg-black/20 border-b border-cyan-500/20">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-lg flex items-center justify-center">
              <span className="text-xl font-bold">🎲</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                CryptoCasino
              </h1>
              <p className="text-xs text-cyan-400">Provably Fair Gaming</p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#games" className="text-gray-300 hover:text-cyan-400 transition-colors">Games</a>
            <a href="#sports" className="text-gray-300 hover:text-cyan-400 transition-colors">Sports</a>
            <a href="#promotions" className="text-gray-300 hover:text-cyan-400 transition-colors">Promotions</a>
            <a href="#vip" className="text-gray-300 hover:text-cyan-400 transition-colors">VIP</a>
          </nav>

          {/* User Section */}
          <div className="flex items-center space-x-4">
            {!loading && user && profile && (
              <div className="flex items-center space-x-3">
                {/* User Balance */}
                <div className="flex items-center space-x-2 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-500/30 rounded-lg px-3 py-2">
                  <Coins className="w-4 h-4 text-cyan-400" />
                  <span className="text-cyan-400 font-medium">
                    ${profile.balance.toFixed(2)}
                  </span>
                </div>

                {/* Username */}
                <div className="flex items-center space-x-2 text-gray-300">
                  <User className="w-4 h-4" />
                  <span>{profile.username || 'Player'}</span>
                </div>
              </div>
            )}

            <Button
              variant="outline"
              className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10 hover:border-cyan-400"
            >
              Live Chat
            </Button>
            
            <Button
              onClick={handleAuthAction}
              disabled={loading}
              className={`${
                user 
                  ? 'bg-red-500 hover:bg-red-600' 
                  : 'bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700'
              } text-white font-medium transition-all duration-300 flex items-center space-x-2`}
            >
              {loading ? (
                'Loading...'
              ) : user ? (
                <>
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </>
              ) : (
                'Sign In'
              )}
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
