
import Header from '../components/Header';
import Hero from '../components/Hero';
import GameGrid from '../components/GameGrid';
import LiveStats from '../components/LiveStats';
import TrendingGames from '../components/TrendingGames';
import Features from '../components/Features';

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white overflow-hidden">
      {/* Animated background particles */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-slate-900/40 to-black"></div>
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 3}s`
            }}
          >
            <div className="w-1 h-1 bg-cyan-400 rounded-full opacity-60"></div>
          </div>
        ))}
      </div>

      <div className="relative z-10">
        <Header />
        <Hero />
        <LiveStats />
        <GameGrid />
        <TrendingGames />
        <Features />
      </div>
    </div>
  );
};

export default Index;
